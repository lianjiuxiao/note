iCheck.js
=========

#### Moved to http://github.com/fronteed/iCheck

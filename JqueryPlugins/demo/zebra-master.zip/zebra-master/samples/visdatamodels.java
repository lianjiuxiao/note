public class Test
extends Object
{    
	static {
		if (a == 1) a++;    
	}
}
<?php
	class BillAction extends Action{
		Public function index(){
			$this->display();
		}
	}
?>